export class Telegram {}
