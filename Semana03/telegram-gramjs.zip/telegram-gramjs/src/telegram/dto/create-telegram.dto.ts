export class CreateTelegramDto {}
